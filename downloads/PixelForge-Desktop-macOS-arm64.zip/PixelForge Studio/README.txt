PIXELFORGE DESKTOP STUDIO - macOS Apple Silicon
Extract this ZIP. Keep the files together. Double-click Open PixelForge.command.
Use the console to load and run .pf cartridges, and F1-F5 for code, sprites, map, SFX and music.
Save a new copy before editing the examples. Downloads do not synchronize with browser storage.
This build was compiled for macOS arm64. Ruby and Gravity language runtimes are not included in this build. It is not a Windows or Intel Mac executable.
