#!/bin/zsh
set -eu
STUDIO_DIR=${0:A:h}
cd "$STUDIO_DIR"
exec "$STUDIO_DIR/pixelforge" --skip --fs "$STUDIO_DIR/cartridges"
